Here are some things to try on deployments
1. Make sure you change the default API endpoints in main.ts in your front end project.
2. Make sure you change the appsettings.json or add an app service configuration value for RedirectRootUrl to point to your static web app.
3. Check the Azure setup instructions
