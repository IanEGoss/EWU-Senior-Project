<template>
  <WordleGame :isWordOfTheDay="false"></WordleGame>
</template>

<script setup lang="ts">
import WordleGame from '@/components/WordleGame.vue'
</script>
