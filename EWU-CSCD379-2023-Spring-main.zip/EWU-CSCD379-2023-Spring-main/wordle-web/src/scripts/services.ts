export class Services {
  static readonly Display = 'Display'
  static readonly PlayerService = 'PlayerService'
  static readonly SignInService = 'SignInService'
}
