export class Player {
  playerId: string = ''
  name: string = ''
  gameCount: number = 0
  averageAttempts: number = 0
  averageSecondsPerGame: number = 0
}
