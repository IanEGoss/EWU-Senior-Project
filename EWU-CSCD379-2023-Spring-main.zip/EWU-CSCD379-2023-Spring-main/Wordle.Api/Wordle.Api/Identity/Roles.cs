﻿namespace Wordle.Api.Identity
{
    public static class Roles
    {
        public const string Admin = "Admin";
        public const string Special = "Special";
    }
}
